from autocomplete.views import AutocompleteView

autocomplete = AutocompleteView('testapp')
