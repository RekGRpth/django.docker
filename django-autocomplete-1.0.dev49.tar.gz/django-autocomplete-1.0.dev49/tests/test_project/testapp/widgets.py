from autocomplete import widgets

class CustomAutocompleteWidget(widgets.AutocompleteWidget):
    pass

class CustomMultipleAutocompleteWidget(widgets.AutocompleteWidget):
    pass
